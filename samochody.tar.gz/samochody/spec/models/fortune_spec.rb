require 'spec_helper'

describe Fortune do
  pending "add some examples to (or delete) #{__FILE__}"
end
