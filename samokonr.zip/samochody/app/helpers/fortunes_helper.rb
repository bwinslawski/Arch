module FortunesHelper
end
