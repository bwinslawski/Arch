# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Samochody::Application.config.secret_token = 'e5ee606ae5560f3eb38d7f7abc106ca2174a79b2a8c96e2ab0df19aef92b4b2bde444c3da5999a356c6f0190f1e5d9a1f33b381df531bfdebf82d0212af03269'
