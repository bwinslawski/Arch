module FortunesHelper

end
